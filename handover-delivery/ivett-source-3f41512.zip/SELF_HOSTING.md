# Hosting Ivett Kovacs PMU

For the full service on Raspberry Pi, custom domains, HTTPS and email setup, see [RASPBERRY_PI.md](RASPBERRY_PI.md).

Two builds share the same design, photos, Hungarian/English content and service list.

| | GitHub Pages | Docker |
|---|---|---|
| Services, prices, biography, contact, FAQ | Yes | Yes |
| Category gallery and enlarged photos | Yes | Yes |
| Reservations and availability | No; buttons lead to contact details | Yes |
| Admin editing and uploads | No | Yes |
| Stored data | Content committed in the repository | SQLite and uploaded files in a Docker volume |

## GitHub repository and validation

Push this project into the private GitHub repository. Keep `.env`, database files and local test data out of Git; the supplied ignore files already exclude them. The **Validate application** workflow runs on pushes and pull requests. It installs locked dependencies, verifies every reservation email type in Hungarian and English, and builds the production application. It does not publish or replace the live Docker service.

### Optional static brochure

Local build: `npm ci` then `npm run build:pages`.
For a project URL such as `https://owner.github.io/ivett/`, build with `PAGES_BASE_PATH=/ivett/ npm run build:pages`. Use `/` for a custom domain or an account-level Pages site. Publishing this brochure requires separately enabling and configuring GitHub Pages; it is not part of the production setup.

The static build uses `lib/services.ts`, `lib/catalog.ts`, `lib/content.ts`, `lib/portfolio.ts` and `public/photos`. Changes made through Docker or Sites admin are **not automatically copied into a static build**. Update the source content, rebuild, and republish it manually. A static brochure has no admin, reservations, API server, email credentials or client booking records.

The purchased domains are `www.ivettkovacspmu.hu` (primary) and `www.ivettkovacspmu.com` (redirect). The live `.hu` website uses Docker and Cloudflare Tunnel.

## Docker: full website

Install Docker Engine with Compose, then run from the project directory:

```sh
docker compose up -d --build
```

Open `http://127.0.0.1:3000`. Admin is at `/admin`; initial login is **admin / admin**, with mandatory password change. Existing passwords survive rebuilds. The container runs as an unprivileged user. For this Windows laptop's startup, backups, and Cloudflare Tunnel steps, see [WINDOWS_HOSTING.md](WINDOWS_HOSTING.md).

The database, reservation history, edited services/FAQ/contact details and uploaded images live in the `ivett-data` named volume, mounted at `/data`. Migrations run transactionally on first database use, and are tracked so restarts do not reapply them. Run a single application instance with this volume. Do not use `docker compose down -v` unless you intend to erase the data.

For remote access, put an HTTPS reverse proxy on the same host in front of `127.0.0.1:3000`. Set `PUBLIC_ORIGIN=https://your-domain.hu` in your local `.env`. This exact origin is used for request protection and secure session cookies. The default port binding is local-only so the initial setup is not exposed before you configure it. The standalone server does not inherit the private Sites access gate: once your proxy exposes it, its public website is reachable, while `/admin` still requires the app's login.

Optional `.env` settings:

```dotenv
PUBLIC_ORIGIN=https://your-domain.hu
RESEND_API_KEY=
RESEND_FROM=
DEEPL_API_KEY=
```

Resend requires a verified sender and API key. DeepL enables automatic translation for newly edited public content. Secrets are supplied at runtime, excluded from the image, and never sent to the static site. The existing Sites database and uploads are not migrated into Docker automatically; a fresh container starts with the source content and these 15 supplied gallery photos.

### Backup and updates

Stop the web container before taking a consistent backup of the entire `ivett-data` volume (database, WAL files and uploads together); restart after backing up. Restore into an empty volume with ownership writable by the image's `node` user. Back up before applying updates, then rerun `docker compose up -d --build`. Keep backups outside the Docker host.

### Validation

The Pages build was checked under `/ivett/`. The production Next.js Docker image and Compose launch passed on this Windows laptop. A disposable container was checked for automatic migrations, all supplied photos, FAQ, password rotation, authorization, origin protection, uploads/hiding, overlapping reservations, a queued request receipt, confirmation, cancellation, and availability after cancellation. Live email delivery still requires Resend configuration.

To repeat the API check against a **new disposable local instance only**:

```sh
python3 tests/docker-smoke.py http://localhost:3100
```

This test changes the disposable admin password and creates test data. Never run it against your working studio database.

## Admin password recovery

Set `ADMIN_RECOVERY_EMAIL` to the owner's trusted inbox (Ivett's supplied address is ivettkovacs5@gmail.com), `PUBLIC_ORIGIN` to the exact HTTPS website origin, and configure `RESEND_API_KEY` and `RESEND_FROM`. The login page's Forgot your password link emails that fixed recipient; visitors cannot select the recipient. Public contact edits do not change the recovery address. Keep these values in environment settings, never Git.

Reset links expire after 30 minutes, are single-use and are stored only as hashes. Requests are limited to one per five minutes. A successful reset invalidates all existing admin sessions. Tokens are carried in URL fragments and removed from the address bar when the reset form opens. Without email configuration, recovery displays an explicit unavailable message.
