import {db,validDate,future,sameOrigin} from '@/lib/server';
import {getServices} from '@/lib/catalog-server';
import {ensureSchedule,windowsSql,type Block} from '@/lib/schedule';
import {notificationPayload,sendNotification} from '@/lib/email';

export async function GET(req:Request){
 try{
  await ensureSchedule();
  const services=(await getServices()).filter(s=>s.active);
  const p=new URL(req.url).searchParams,date=p.get('date')||'',service=p.get('service')||'';
  if(!validDate(date)||!services.some(s=>s.id===service))return Response.json({error:'invalid'}, {status:400});
  const duration=services.find(s=>s.id===service)?.minutes;
  if(!duration)return Response.json({slots:[],configured:false,reason:'duration_missing'});
  const windows=await db().prepare(windowsSql).bind(date,date).all<{start:number,end:number}>();
  const reservations=await db().prepare("SELECT start,end FROM bookings WHERE date=? AND status NOT IN ('cancelled','rejected')").bind(date).all<{start:number,end:number}>();
  const blocks=await db().prepare('SELECT start,end FROM time_blocks WHERE date_from<=? AND date_to>=?').bind(date,date).all<Block>();
  const slots=new Set<number>();
  for(const w of windows.results)for(let n=w.start;n+duration<=w.end;n+=30)if(future(date,n)&&!blocks.results.some(b=>n<b.end&&n+duration>b.start)&&!reservations.results.some(b=>n<b.end&&n+duration>b.start))slots.add(n);
  return Response.json({slots:[...slots].sort((a,b)=>a-b),duration,configured:true,reason:slots.size?'available':blocks.results.some(b=>b.start===0&&b.end===1440)?'blocked':!windows.results.length?'closed':!windows.results.some(w=>w.end-w.start>=duration)?'too_short':'full'});
 }catch(e){console.error(e);return Response.json({error:'unavailable'},{status:503});}
}

export async function POST(req:Request){
 if(!sameOrigin(req))return Response.json({error:'forbidden'},{status:403});
 try{
  await ensureSchedule();
  const services=(await getServices()).filter(s=>s.active);
  const b=await req.json() as {date:string,start:number,service:string,name:string,email:string,phone:string,consent:boolean,previousTreatment:string,previousDetails:string,referral:string,quotedPrice:number,language?:string};
  if(!validDate(b.date)||!Number.isInteger(b.start)||!future(b.date,b.start)||!services.some(s=>s.id===b.service)||typeof b.name!=='string'||b.name.trim().length<2||b.name.length>100||typeof b.email!=='string'||!/^\S+@\S+\.\S+$/.test(b.email)||b.email.length>200||typeof b.phone!=='string'||!/^[+\d ()-]{6,30}$/.test(b.phone)||b.consent!==true||!['yes','no'].includes(b.previousTreatment)||typeof b.previousDetails!=='string'||b.previousDetails.length>1000||(b.previousTreatment==='yes'&&!b.previousDetails.trim())||typeof b.referral!=='string'||b.referral.length>200)return Response.json({error:'invalid'},{status:400});
  const selected=services.find(s=>s.id===b.service)!;
  if(b.quotedPrice!==selected.price)return Response.json({error:'price_changed'},{status:409});
  if(!selected.minutes)return Response.json({error:'unavailable'},{status:409});
  const id=crypto.randomUUID(),event=crypto.randomUUID(),created=new Date().toISOString();
  const name=b.name.trim(),email=b.email.trim(),language=b.language==='en'?'en':'hu';
  const payload=await notificationPayload({id,service:b.service,date:b.date,start:b.start,end:b.start+selected.minutes,name,email,status:'pending',language,service_name:selected.hu,booked_price:selected.price,status_event:event},'pending');
  const insert=db().prepare(`INSERT INTO bookings (id,service,date,start,end,name,email,phone,status,created,previous_treatment,previous_details,referral,booked_price,service_name,language,status_event) SELECT ?,?,?,?,?+d.minutes,?,?,?,'pending',?,?,?,?,?,?,?,? FROM durations d WHERE d.service=? AND NOT EXISTS (SELECT 1 FROM service_catalog c WHERE c.id=d.service AND c.active=0) AND EXISTS (SELECT 1 FROM (${windowsSql}) a WHERE a.start<=? AND a.end>=?+d.minutes AND (? - a.start)%30=0) AND NOT EXISTS (SELECT 1 FROM time_blocks x WHERE x.date_from<=? AND x.date_to>=? AND x.start<?+d.minutes AND x.end>?) AND NOT EXISTS (SELECT 1 FROM bookings b WHERE b.date=? AND b.status NOT IN ('cancelled','rejected') AND b.start<?+d.minutes AND b.end>?)`).bind(id,b.service,b.date,b.start,b.start,name,email,b.phone,created,b.previousTreatment,b.previousTreatment==='yes'?b.previousDetails.trim():'',b.referral.trim(),selected.price,selected.hu,language,event,b.service,b.date,b.date,b.start,b.start,b.start,b.date,b.date,b.start,b.start,b.date,b.start,b.start);
  const outbox=db().prepare("INSERT INTO email_outbox(id,booking_id,kind,payload,state,created) SELECT ?,id,'pending',?,'queued',? FROM bookings WHERE id=? AND status_event=?").bind(event,JSON.stringify(payload),created,id,event);
  const [result]=await db().batch([insert,outbox]);
  if(!result.meta.changes)return Response.json({error:'unavailable'},{status:409});
  const delivery=await sendNotification(event);
  return Response.json({id,email:delivery});
 }catch(e){console.error(e);return Response.json({error:'unavailable'},{status:503});}
}
